# Arena Game

## Overview
This is a simple implementation of the Magical Arena game. In this game, two players take turns attacking each other until one player's health reaches 0.

## How to Run

1. **Compile the code:**

javac src/main/java/*.java


2. **Run the game:**

java -cp src/main/java Arena


## Testing

1. **Compile the tests:**


Here's a simple implementation of the Magical Arena game in Java, following the given rules and criteria. This solution includes the main game logic, a README file, and unit tests.

Project Structure
arduino
Copy code
MagicalArena/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   ├── MagicalArena.java
│   │   │   ├── Player.java
│   ├── test/
│   │   ├── java/
│   │   │   ├── MagicalArenaTest.java
│   │   │   ├── PlayerTest.java
├── README.md
├── .gitignore
├── build.gradle (optional, if using Gradle)
Player.java
java
Copy code
public class Player {
    private int health;
    private int strength;
    private int attack;

    public Player(int health, int strength, int attack) {
        this.health = health;
        this.strength = strength;
        this.attack = attack;
    }

    public int getHealth() {
        return health;
    }

    public int getStrength() {
        return strength;
    }

    public int getAttack() {
        return attack;
    }

    public void reduceHealth(int damage) {
        this.health = Math.max(0, this.health - damage);
    }

    public boolean isAlive() {
        return this.health > 0;
    }
}
MagicalArena.java
java
Copy code
import java.util.Random;

public class MagicalArena {
    private static final Random random = new Random();

    public static void main(String[] args) {
        Player playerA = new Player(50, 5, 10);
        Player playerB = new Player(100, 10, 5);

        while (playerA.isAlive() && playerB.isAlive()) {
            playRound(playerA, playerB);
        }

        if (playerA.isAlive()) {
            System.out.println("Player A wins!");
        } else {
            System.out.println("Player B wins!");
        }
    }

    private static void playRound(Player playerA, Player playerB) {
        if (playerA.getHealth() <= playerB.getHealth()) {
            attack(playerA, playerB);
            if (playerB.isAlive()) {
                attack(playerB, playerA);
            }
        } else {
            attack(playerB, playerA);
            if (playerA.isAlive()) {
                attack(playerA, playerB);
            }
        }
    }

    private static void attack(Player attacker, Player defender) {
        int attackRoll = rollDie();
        int defendRoll = rollDie();

        int damage = (attacker.getAttack() * attackRoll) - (defender.getStrength() * defendRoll);
        damage = Math.max(0, damage);
        defender.reduceHealth(damage);

        System.out.println("Attacker: " + attacker.getAttack() + ", Defender: " + defender.getStrength());
        System.out.println("Attack roll: " + attackRoll + ", Defend roll: " + defendRoll);
        System.out.println("Damage dealt: " + damage);
        System.out.println("Defender's health: " + defender.getHealth());
    }

    private static int rollDie() {
        return random.nextInt(6) + 1;
    }
}
MagicalArenaTest.java
java
Copy code
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MagicalArenaTest {

    @Test
    public void testPlayerCreation() {
        Player player = new Player(50, 5, 10);
        assertEquals(50, player.getHealth());
        assertEquals(5, player.getStrength());
        assertEquals(10, player.getAttack());
    }

    @Test
    public void testPlayerReduceHealth() {
        Player player = new Player(50, 5, 10);
        player.reduceHealth(20);
        assertEquals(30, player.getHealth());
        player.reduceHealth(40);
        assertEquals(0, player.getHealth());
    }

    @Test
    public void testPlayerIsAlive() {
        Player player = new Player(50, 5, 10);
        assertTrue(player.isAlive());
        player.reduceHealth(50);
        assertFalse(player.isAlive());
    }
}
PlayerTest.java
java
Copy code
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PlayerTest {

    @Test
    public void testPlayerCreation() {
        Player player = new Player(50, 5, 10);
        assertEquals(50, player.getHealth());
        assertEquals(5, player.getStrength());
        assertEquals(10, player.getAttack());
    }

    @Test
    public void testPlayerReduceHealth() {
        Player player = new Player(50, 5, 10);
        player.reduceHealth(20);
        assertEquals(30, player.getHealth());
        player.reduceHealth(40);
        assertEquals(0, player.getHealth());
    }

    @Test
    public void testPlayerIsAlive() {
        Player player = new Player(50, 5, 10);
        assertTrue(player.isAlive());
        player.reduceHealth(50);
        assertFalse(player.isAlive());
    }
}
README.md
markdown
Copy code
# Magical Arena Game

## Overview
This is a simple implementation of the Magical Arena game. In this game, two players take turns attacking each other until one player's health reaches 0.

## How to Run

1. **Compile the code:**

javac src/main/java/*.java

markdown
Copy code

2. **Run the game:**

java -cp src/main/java MagicalArena

markdown
Copy code

## Testing

1. **Compile the tests:**

javac -cp .
.7.0.jar: src/test/java/*.java





## Files

- `Die.java`: Contains the main game logic.
- `Player.java`: Defines the Player class.
- `Arena.java`: Contains the unit tests for the game logic.
- `Main.java`: Contains the unit tests for the Player class.
- `readme.md`: Provides an overview and instructions for running the game.
