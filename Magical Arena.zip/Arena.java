
public class Arena {
    private Die die;

    public Arena() {
        this.die = new Die();
    }

    public void fight(Player playerA, Player playerB) {
        Player attacker = playerA.getHealth() <= playerB.getHealth() ? playerA : playerB;
        Player defender = attacker == playerA ? playerB : playerA;

        System.out.println("Fight starts between " + playerA.getName() + " and " + playerB.getName());

        while (playerA.isAlive() && playerB.isAlive()) {
            performAttack(attacker, defender);

            // Swap attacker and defender
            Player temp = attacker;
            attacker = defender;
            defender = temp;
        }

        Player winner = playerA.isAlive() ? playerA : playerB;
        System.out.println(winner.getName() + " wins the fight!");
    }

    private void performAttack(Player attacker, Player defender) {
        int attackRoll = die.roll();
        int defendRoll = die.roll();

        int attackDamage = attacker.getAttack() * attackRoll;
        int defendStrength = defender.getStrength() * defendRoll;

        int damageTaken = Math.max(0, attackDamage - defendStrength);
        defender.setHealth(defender.getHealth() - damageTaken);

        System.out.println(attacker.getName() + " attacks " + defender.getName());
        System.out.println("Attack roll: " + attackRoll + ", Defend roll: " + defendRoll);
        System.out.println("Damage dealt: " + damageTaken);
        System.out.println(defender.getName() + " health: " + defender.getHealth());
        System.out.println();
    }
}
